﻿namespace Kalkulator.Models
{
    public class Calculator
    {
        public int FirstNumber { get; set; }
        public int SecondNumber { get; set; }
        public char Mark { get; set; }
        public int Result { get; set; }
    }
}
